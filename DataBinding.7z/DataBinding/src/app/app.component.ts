import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'Angular Application';
  fname:string="lalitha";
  lname:string=" lally";
  myname:string;
  status:boolean=false;
count:number=0;
address:string;
  getFullName():string{
    this.myname=this.fname+this.lname;
    return this.myname;
  }
  getCount():number{
return ++this.count;
  }
}
